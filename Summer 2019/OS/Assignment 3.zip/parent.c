#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <assert.h>
#include <signal.h>
#include <string.h>
#include "syscall.h"
#include <errno.h>

/*
Joshua Hoshiko
CS3600
Project 3

Note: Collaborated with John and Gerom
 Assisted Emily, Calan, and Luke
*/
static void handler(int signal) {
    int status, returnedStatus;
    waitpid(-1, &status, 0);
    if (WIFSIGNALED(status)) {
        returnedStatus = WEXITSTATUS(status);
        WRITESTRING("Child process returned status: ")
        WRITEINT(returnedStatus, 3)
    }
    exit(0);
}

int main() {

    //Fork process
    pid_t pid = fork();

    //Make sure nothing broke during the fork
    if(pid < 0) {
        perror("Fork Failed");
        exit(EXIT_FAILURE);
    }

        //Child
    else if(pid == 0) {
        execl("./child", "child", 0);
        exit(0);
    }

        //Parent
    else {
        struct sigaction action;
        action.sa_handler = handler;
        sigemptyset(&action.sa_mask);
        action.sa_flags = SA_RESTART | SA_NOCLDSTOP;
        assert(sigaction(SIGCHLD, &action, NULL) == 0);

        int i;
        for(i = 0; i < 5; ++i) {
            assert (printf("SIGSTOP Child\n") != 0);
            assert(kill(pid,SIGSTOP) == 0);
            sleep(2);
            assert (printf("SIGCONT Child\n") != 0);
            assert(kill(pid,SIGCONT) == 0);
            sleep(2);
        }
        assert(kill(pid,SIGINT) == 0);
        pause();
    }
    return 0;
}