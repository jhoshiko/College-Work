#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/*
Joshua Hoshiko
CS3600
Project 3

Note: Collaborated with John and Gerom
 Assisted Emily, Calan, and Luke
*/

int main() {

    while(1) {
        assert (printf("Awake in %d\n", getpid()) !=0);
        sleep(1);
    }
    
    exit(0);
}