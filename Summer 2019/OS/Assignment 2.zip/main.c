#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <assert.h>
#include <signal.h>
#include <string.h>
#define _POSIX_C_SOURCE 200009L

/*
Joshua Hoshiko
CS3600
Project 2

Note: Collaborated with John and Gerom
 Assisted Emily, Calan, and Luke
*/
static void handler(int signal){
    if(signal == 28){
        assert(write(1, "Parent: SIGWINCH Received\n", strlen("Parent SIGWINCH Received\n"))!= 0);
    }
    else if(signal == 30){
        assert(write(1, "Parent: SIGUSR1 Received\n", strlen("Parent: SIGUSR1 Received\n"))!= 0);
    }
    else if(signal == 31){
        assert(write (1, "Parent SIGUSR2 Received\n", strlen("Parent: SIGUSR2 Received\n"))!= 0);
    }
}

int main() {

    //Fork process
    pid_t pid = fork();

    //Make sure nothing broke during the fork
    if(pid < 0) {
        perror("Fork");
        exit(EXIT_FAILURE);
    }

        //Child
    else if(pid == 0) {
        execl("./child", "child", 0);
        exit(0);
    }

        //Parent
    else {
        struct sigaction action;
        action.sa_handler = handler;
        sigemptyset(&action.sa_mask);
        action.sa_flags = SA_RESTART;
        assert(sigaction(SIGUSR1, &action, NULL) == 0);
        assert(sigaction(SIGUSR2, &action, NULL) == 0);
        assert(sigaction(SIGWINCH, &action, NULL) == 0);

        int status, returnedStatus, child;
        child = waitpid(pid, &status, 0);

        if(WIFEXITED(status)){
            returnedStatus = WEXITSTATUS(status);
            assert (printf("Process %d exited with status: %d\n",child, returnedStatus)!=0);
        }
    }

    return 0;
}

