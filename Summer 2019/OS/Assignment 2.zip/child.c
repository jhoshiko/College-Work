#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/*
Joshua Hoshiko
CS3600
Project 2

Note: Collaborated with John and Gerom
 Assisted Emily, Calan, and Luke
*/

int main() {
    assert(kill(getppid(), SIGUSR1) == 0);
    assert(printf("Child: SIGUSR1 sent to the parent.\n") != 0);
    assert(kill(getppid(), SIGUSR2) == 0);
    assert(printf("Child: SIGUSR2 sent to the parent.\n") != 0);
    assert(kill(getppid(), SIGWINCH) == 0);
    assert(printf("Child: SIGWINCH sent to the parent.\n") != 0);

    assert(kill(getppid(), SIGUSR1) == 0);
    assert(printf("Child: SIGUSR1 sent to the parent.\n") != 0);
    assert(kill(getppid(), SIGUSR1) == 0);
    assert(printf("Child: SIGUSR1 sent to the parent.\n") != 0);
    assert(kill(getppid(), SIGUSR1) == 0);
    assert(printf("Child: SIGUSR1 sent to the parent.\n") != 0);
    exit(0);
}


