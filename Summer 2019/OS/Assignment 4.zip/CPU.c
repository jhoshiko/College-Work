#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <assert.h>
#include "systemcall.h"

#define NUM_SECONDS 20
#define ever ;;

/*
Joshua Hoshiko
Project 4

Note: Collaborated with John and Gerom. 
Assisted Calan, Emily, and Luke
*/

enum STATE { NEW, RUNNING, WAITING, READY, TERMINATED, EMPTY };

struct PCB {
    enum STATE state;
    const char *name;   // name of the executable
    int pid;            // process id from fork();
    int ppid;           // parent process id
    int interrupts;     // number of times interrupted
    int switches;       // may be < interrupts
    int started;        // the time this process started
};

typedef enum { false, true } bool;

#define PROCESSTABLESIZE 10
struct PCB processes[PROCESSTABLESIZE];

struct PCB idle;
struct PCB *running;

int sys_time;
int timer;
struct sigaction alarm_handler;
struct sigaction child_handler;

void bad(int signum) {
    WRITESTRING("bad signal: ");
    WRITEINT(signum, 4);
    WRITESTRING("\n");
}

// cdecl> declare ISV as array 32 of pointer to function(int) returning void
void(*ISV[32])(int) = {
/*       00   01   02   03   04   05   06   07   08   09 */
/*  0 */ bad, bad, bad, bad, bad, bad, bad, bad, bad, bad,
/* 10 */ bad, bad, bad, bad, bad, bad, bad, bad, bad, bad,
/* 20 */ bad, bad, bad, bad, bad, bad, bad, bad, bad, bad,
/* 30 */ bad, bad
};

void ISR (int signum) {
    if (signum != SIGCHLD) {
        kill (running->pid, SIGSTOP);
        WRITESTRING("Stopping: ");
        WRITEINT(running->pid, 6);
        WRITESTRING("\n");
    }

    ISV[signum](signum);
}

void send_signals(int signal, int pid, int interval, int number) {
    for(int i = 1; i <= number; i++) {
        sleep(interval);
        WRITESTRING("Sending signal: ");
        WRITEINT(signal, 4);
        WRITESTRING(" to process: ");
        WRITEINT(pid, 6);
        WRITESTRING("\n");
        systemcall(kill(pid, signal));
    }

    WRITESTRING("At the end of send_signals\n");
}

void create_handler(int signum, struct sigaction action, void(*handler)(int)) {
    action.sa_handler = handler;

    if (signum == SIGCHLD) {
        action.sa_flags = SA_NOCLDSTOP | SA_RESTART;
    } else {
        action.sa_flags =  SA_RESTART;
    }

    systemcall(sigemptyset(&action.sa_mask));
    systemcall(sigaction(signum, &action, NULL));
}

void scheduler (int signum) {
   WRITESTRING("\n");
   WRITESTRING("---- entering scheduler\n");
    assert(signum == SIGALRM);
   
   //Increment system tim and interrupt counters. Change running process state
   //to READY
    ++sys_time;
    ++running->interrupts;
    running->state = READY;
    
    //This block check for NEW processes that have not been started. Any that
    //are will be forked and excecl'd. This loop will also store a pointer to
    //the last run process for the round robin block
    int count = 0;
    int running_index = 0;
    while(count < PROCESSTABLESIZE && processes[count].name != 0) {
        
        //Last run process pointer
        if(processes[count].pid == running->pid) {
            running_index = count;
        }
        
        if(processes[count].state == NEW) {
            WRITESTRING("Starting NEW process: ");
            WRITESTRING(processes[count].name);
            WRITESTRING("\n");
            ++running->switches;
            running = &processes[count];
            processes[count].state = RUNNING;
            processes[count].started = sys_time;
            processes[count].pid = fork();
    
            //Fork has failed
            if(processes[count].pid < 0) {
                perror("Fork Failed");
                exit(EXIT_FAILURE);
            }
            //Child
            else if(processes[count].pid == 0) {
                processes[count].ppid = getppid();
                WRITESTRING("Parent PID: ");
                WRITEINT (processes[count].ppid, 6);
                WRITESTRING("\n");
                execl(processes[count].name, "Process", NULL);
                exit(0);
            }
            return;
        }
        ++count;
    }
    
    //This block begins a round robin with the process right after the last run 
    //process if there are no NEW processes to start
    WRITESTRING("Entering round robin \n");
   
   //Fix pointer if it exceeds the table size. Increments it to the next process
   //in the list
    if(running_index == PROCESSTABLESIZE) {
        count = 0;
    }
    else {
        count = running_index + 1;
    }
    while(count != running_index) {
        if(processes[count].state == READY) {
            WRITESTRING("Continuing READY process: ");
            WRITESTRING(processes[count].name);
            WRITESTRING("\n");
            WRITESTRING("Process PID: ");
            WRITEINT (processes[count].pid, 6);
            WRITESTRING("\n");
            ++running->switches;
            running = &processes[count];
            processes[count].state = RUNNING;
            systemcall (kill (processes[count].pid, SIGCONT));
            return;
        }
        ++count;
        if(count > PROCESSTABLESIZE) {
            count = 0;
        }
    }
    
    //Continue the IDLE process if there is nothing else to do
    WRITESTRING ("Continuing idle: ");
    WRITEINT (idle.pid, 6);
    WRITESTRING ("\n");
    running = &idle;
    idle.state = RUNNING;
    systemcall (kill (idle.pid, SIGCONT));

    WRITESTRING("---- leaving scheduler\n\n");
}

void process_done (int signum) {
    WRITESTRING("\n");
    //Check  to see if the terminated child process is the TIMER process
    //or a regular child process. If the TIMER expired, kills everything
    if(!kill(running->pid, 0) && running->pid != idle.pid) {
        WRITESTRING("---- entering process_done\n");
        assert (signum == SIGCHLD);
        WRITESTRING ("Child process terminated: ");
        WRITESTRING (running->name);
        WRITESTRING ("\n");
        WRITESTRING ("Process PID: ");
        WRITEINT (running->pid, 6);
        WRITESTRING ("\n");
        WRITESTRING ("Number of interrupts: ");
        WRITEINT (running->interrupts, 3);
        WRITESTRING ("\n");
        WRITESTRING ("Number of switches: ");
        WRITEINT (running->switches, 3);
        WRITESTRING ("\n");
        WRITESTRING ("Total execution time: ");
        WRITEINT (running->started, 3);
        WRITESTRING ("\n");
        running->state = TERMINATED;

        WRITESTRING ("Continuing idle: ");
        WRITEINT (idle.pid, 6);
        WRITESTRING ("\n");
        running = &idle;
        idle.state = RUNNING;
        systemcall (kill (idle.pid, SIGCONT));
    }
    else {
        WRITESTRING ("Timer died, cleaning up and killing everything\n");
        systemcall(kill(0, SIGTERM))
        exit(0);
    }

    WRITESTRING ("---- leaving process_done\n\n");
}

void boot()
{
    sys_time = 0;

    ISV[SIGALRM] = scheduler;
    ISV[SIGCHLD] = process_done;
    create_handler(SIGALRM, alarm_handler, ISR);
    create_handler(SIGCHLD, child_handler, ISR);

    assert((timer = fork()) != -1);
    if (timer == 0) {
        send_signals(SIGALRM, getppid(), 1, NUM_SECONDS);
        exit(0);
    }
}

void create_idle() {
    idle.state = READY;
    idle.name = "IDLE";
    idle.ppid = getpid();
    idle.interrupts = 0;
    idle.switches = 0;
    idle.started = sys_time;

    assert((idle.pid = fork()) != -1);
    if (idle.pid == 0) {
        systemcall(pause());
    }
}

int main(int argc, char **argv) {
    WRITESTRING ("Beginning Main: \n")
    
    boot();
    create_idle();
    running = &idle;

    //Load all arguments into the process table with a state of NEW
    int count;
    for(count = 0; count < argc-1; ++count) {
        processes[count].state = NEW;
        processes[count].name = argv[count+1];
    }

    for(ever) {
        pause();
    }
}